#include "syscall.h"
int 
main()
{
	char temp[50];
	int limit=50;
	PrintString("hellooo\n");
	PrintString("\n------ECHO-------\n");
	PrintString("Nhap chuoi: ");
	ReadString(temp,limit);
	PrintString("\n\nChuoi la: ");
	PrintString(temp);
	return 0;
}
