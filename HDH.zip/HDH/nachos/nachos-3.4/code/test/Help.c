#include "syscall.h"
int 
main()
{
	PrintString("\n-------------HELP-------------\n");
	PrintString("---------Thong tin nhom---------\n");
	PrintString("Nguyen Chau Anh Nguyen\t19120104\n");
	PrintString("Truong Phu Hung\t\t19120236\n");
	PrintString("Huynh Ngoc Bao\t\t19120455\n");
	PrintString("Pham Huu Phuoc\t\t19120120\n");
	PrintString("Nguyen Trong Kha\t19120083\n\n");
	PrintString("Chuong trinh ascii: In ra bang ma ascii\n");
	PrintString("Chuong trinh sort: Nhap vao mang so nguyen co it hon 100 phan tu va sap xep mang");
	return 0;
}
