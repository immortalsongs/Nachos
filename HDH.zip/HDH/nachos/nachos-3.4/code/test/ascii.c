#include "syscall.h"
int 
main()
{
	int i;
	char k;
	for(i=1; i<128;i++)
	{
		PrintInt(i);
		PrintString("\t");
		k=i;
		PrintChar(k);
		PrintString("\n");
	}
	return 0;
}
